package databasegui;

import databasegui.LoginWindow.LoginWindow;
import databasegui.MainWindow.MainWindow;

public class Main {

    public static void main(String[] args) { LoginWindow.launchApp(); }
}
